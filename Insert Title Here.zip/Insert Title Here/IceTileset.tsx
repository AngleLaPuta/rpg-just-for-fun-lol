<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="IceTileset" tilewidth="32" tileheight="32" tilecount="180" columns="20">
 <image source="../../Downloads/IceTileset.png" width="640" height="288"/>
</tileset>
